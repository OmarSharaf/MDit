# MDit — Professional Markdown Editor

A sleek, high-performance Markdown editor for Windows (and macOS/Linux) built with **Tauri 2 + React 18 + TypeScript**.

---

## Features

- **Live split-view preview** — editor and rendered output side-by-side
- **Multi-tab editing** — work on multiple files at once
- **Full file system access** — open, edit, save `.md` files natively via OS dialogs
- **Rich formatting toolbar** — bold, italic, headings, lists, tables, code blocks, links
- **Find & Replace** — full regex support, case-sensitive search, match counter
- **Focus mode** — F11 hides all UI chrome for distraction-free writing
- **Smart list continuation** — Enter in a list auto-continues the pattern
- **Auto-close brackets** — `(`, `[`, `{`, `"`, `` ` `` auto-paired
- **Recent files** panel in sidebar
- **Settings** — font size, line height, word wrap, spell check, auto-save
- **Status bar** — word count, char count, line count, reading time
- **Lightweight** — Tauri uses ~10x less RAM than Electron

---

## Tech Stack

| Layer | Technology |
|-------|-----------|
| App shell | Tauri 2.x (Rust) |
| Frontend | React 18 + TypeScript + Vite |
| State | Zustand |
| Markdown preview | react-markdown + remark-gfm + rehype-highlight |
| Styling | CSS Modules |
| Icons | Lucide React |
| File dialogs | @tauri-apps/plugin-dialog |
| File I/O | @tauri-apps/plugin-fs |

---

## Prerequisites

### 1. Node.js (v18+)
Download from https://nodejs.org

### 2. Rust
```bash
# Windows (run in PowerShell)
winget install Rustlang.Rust.MSVC

# Or via rustup:
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
```

### 3. Microsoft C++ Build Tools (Windows only)
Download **Visual Studio Build Tools** from:
https://visualstudio.microsoft.com/visual-cpp-build-tools/

Select: **Desktop development with C++**

### 4. WebView2 (Windows — usually pre-installed on Win 10/11)
If missing: https://developer.microsoft.com/en-us/microsoft-edge/webview2/

---

## Getting Started

```bash
# 1. Clone / extract the project
cd mdit

# 2. Install Node dependencies
npm install

# 3. Start in development mode (hot reload)
npm run tauri dev

# 4. Build production .exe installer
npm run tauri build
```

The built installer will be at:
```
src-tauri/target/release/bundle/msi/MDit_1.0.0_x64_en-US.msi
src-tauri/target/release/bundle/nsis/MDit_1.0.0_x64-setup.exe
```

---

## Development

```bash
# Frontend only (no Tauri, runs in browser)
npm run dev
# Open http://localhost:1420
# File open/save will use browser fallbacks (download dialog)

# Full Tauri dev mode
npm run tauri dev

# Type check
npx tsc --noEmit

# Build frontend only
npm run build
```

---

## Project Structure

```
mdit/
├── src/                    # React frontend
│   ├── components/
│   │   ├── TitleBar.tsx        # App titlebar + menu
│   │   ├── Sidebar.tsx         # File explorer + recent files
│   │   ├── TabBar.tsx          # Multi-tab bar
│   │   ├── EditorPane.tsx      # Split view container
│   │   ├── EditorToolbar.tsx   # Formatting toolbar
│   │   ├── MarkdownEditor.tsx  # Textarea editor
│   │   ├── MarkdownPreview.tsx # Rendered preview
│   │   ├── SearchOverlay.tsx   # Find & replace
│   │   └── SettingsPanel.tsx   # Settings modal
│   ├── hooks/
│   │   └── useFileActions.ts   # File open/save hooks
│   ├── store/
│   │   └── useStore.ts         # Zustand state store
│   ├── utils/
│   │   ├── fileSystem.ts       # Tauri FS bridge
│   │   └── markdown.ts         # Formatting utilities
│   └── styles/
│       └── globals.css
├── src-tauri/              # Rust backend
│   ├── src/
│   │   ├── main.rs
│   │   └── lib.rs          # Tauri commands
│   ├── capabilities/
│   │   └── default.json    # Permissions
│   ├── Cargo.toml
│   └── tauri.conf.json
└── package.json
```

---

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `Ctrl+N` | New file |
| `Ctrl+O` | Open file |
| `Ctrl+S` | Save |
| `Ctrl+Shift+S` | Save As |
| `Ctrl+F` | Find & Replace |
| `Ctrl+B` | Bold |
| `Ctrl+I` | Italic |
| `Ctrl+K` | Insert link |
| `Ctrl+\` | Toggle sidebar |
| `Tab` | Insert 2 spaces |
| `F11` | Toggle focus mode |
| `Esc` | Exit focus mode / close search |

---

## Customization

To extend MDit:

- **Add themes**: Edit CSS variables in `src/styles/globals.css`
- **Add commands**: Add `#[tauri::command]` functions in `src-tauri/src/lib.rs`
- **Add toolbar buttons**: Extend `EditorToolbar.tsx` and `markdown.ts`
- **Add settings**: Add fields to `AppSettings` in `useStore.ts`

---

## License

MIT — use freely, modify as needed.
