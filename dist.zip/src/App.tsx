import { useEffect } from "react";
import { useStore } from "./store/useStore";
import { TitleBar } from "./components/TitleBar";
import { Sidebar } from "./components/Sidebar";
import { TabBar } from "./components/TabBar";
import { EditorPane } from "./components/EditorPane";
import { StatusBar } from "./components/StatusBar";
import { SearchOverlay } from "./components/SearchOverlay";
import { SettingsPanel } from "./components/SettingsPanel";
import { AboutDialog } from "./components/AboutDialog";
import { CommandPalette } from "./components/CommandPalette";
import { GitHubImportDialog } from "./components/GitHubImportDialog";
import { useFileActions } from "./hooks/useFileActions";
import { useAutoSave } from "./hooks/useAutoSave";
import { useTheme } from "./hooks/useTheme";
import { useSession } from "./hooks/useSession";
import { useFileWatch } from "./hooks/useFileWatch";
import styles from "./App.module.css";
import { useState } from "react";

export default function App() {
  const sidebarOpen = useStore((s) => s.sidebarOpen);
  const focusMode = useStore((s) => s.settings.focusMode);
  const viewMode = useStore((s) => s.viewMode);
  const toggleFocusMode = useStore((s) => s.toggleFocusMode);
  const openCommandPalette = useStore((s) => s.openCommandPalette);
  const hasUnsavedTabs = useStore((s) => s.hasUnsavedTabs);
  const { handleNew, handleOpen, handleSave, handleSaveAs } = useFileActions();
  const openSearch = useStore((s) => s.openSearch);
  const toggleSidebar = useStore((s) => s.toggleSidebar);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [githubImportOpen, setGitHubImportOpen] = useState(false);
  const createTab = useStore((s) => s.createTab);
  const setSaveStatus = useStore((s) => s.setSaveStatus);
  const tabs = useStore((s) => s.tabs);
  const activeTabId = useStore((s) => s.activeTabId);
  const setActiveTab = useStore((s) => s.setActiveTab);

  useTheme();
  useAutoSave();
  useSession();
  useFileWatch();

  useEffect(() => {
    if (!activeTabId && tabs.length) setActiveTab(tabs[0].id);
  }, [activeTabId, tabs, setActiveTab]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "n") { e.preventDefault(); handleNew(); }
      if (mod && e.key.toLowerCase() === "o") { e.preventDefault(); handleOpen(); }
      if (mod && e.key.toLowerCase() === "s" && e.shiftKey) { e.preventDefault(); handleSaveAs(); }
      else if (mod && e.key.toLowerCase() === "s") { e.preventDefault(); handleSave(); }
      if (mod && e.key.toLowerCase() === "f") { e.preventDefault(); openSearch(); }
      if (mod && e.shiftKey && e.key.toLowerCase() === "p") {
        e.preventDefault();
        openCommandPalette();
      }
      if (mod && e.key === "\\") { e.preventDefault(); toggleSidebar(); }
      if (e.key === "F11") { e.preventDefault(); toggleFocusMode(); }
      if (e.key === "Escape" && focusMode) toggleFocusMode();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [
    focusMode,
    handleNew,
    handleOpen,
    handleSave,
    handleSaveAs,
    openSearch,
    openCommandPalette,
    toggleSidebar,
    toggleFocusMode,
  ]);

  useEffect(() => {
    const onBeforeUnload = (e: BeforeUnloadEvent) => {
      if (hasUnsavedTabs()) {
        e.preventDefault();
        e.returnValue = "";
      }
    };
    window.addEventListener("beforeunload", onBeforeUnload);
    return () => window.removeEventListener("beforeunload", onBeforeUnload);
  }, [hasUnsavedTabs]);

  const hideChrome = focusMode || viewMode === "presentation";

  return (
    <div className={`${styles.app} ${focusMode ? styles.focusMode : ""}`}>
      {!hideChrome && (
        <TitleBar
          onSettings={() => setSettingsOpen(true)}
          onAbout={() => setAboutOpen(true)}
        />
      )}
      <div className={styles.body}>
        {!hideChrome && sidebarOpen && <Sidebar onGitHubImport={() => setGitHubImportOpen(true)} />}
        <div className={styles.content}>
          {!hideChrome && <TabBar />}
          <EditorPane />
          {!hideChrome && <StatusBar onAbout={() => setAboutOpen(true)} />}
        </div>
      </div>
      <SearchOverlay />
      <CommandPalette
        onAbout={() => setAboutOpen(true)}
        onGitHubImport={() => setGitHubImportOpen(true)}
      />
      {settingsOpen && (
        <SettingsPanel
          onClose={() => setSettingsOpen(false)}
          onAbout={() => {
            setSettingsOpen(false);
            setAboutOpen(true);
          }}
        />
      )}
      {aboutOpen && <AboutDialog onClose={() => setAboutOpen(false)} />}
      <GitHubImportDialog
        open={githubImportOpen}
        onClose={() => setGitHubImportOpen(false)}
        onImported={(name, content) => {
          createTab(name, content, null);
          setSaveStatus("saved", `Imported ${name} from GitHub`);
          window.setTimeout(() => setSaveStatus("idle"), 2500);
        }}
      />
    </div>
  );
}
