import { useRef, useCallback, useState } from "react";
import { Plus, FolderOpen, Columns2 } from "lucide-react";
import { useStore, useActiveTab } from "../store/useStore";
import { useFileActions } from "../hooks/useFileActions";
import { EditorToolbar } from "./EditorToolbar";
import { MarkdownEditor } from "./MarkdownEditor";
import { MarkdownPreview, PreviewHandle } from "./MarkdownPreview";
import { FrontMatterPanel } from "./FrontMatterPanel";
import { scrollEditorToRange } from "../utils/editorRef";
import styles from "./EditorPane.module.css";

export function EditorPane() {
  const viewMode = useStore((s) => s.viewMode);
  const activeTab = useActiveTab();
  const setViewMode = useStore((s) => s.setViewMode);
  const focusMode = useStore((s) => s.settings.focusMode);
  const syncSelection = useStore((s) => s.settings.syncScroll);
  const showFrontMatter = useStore((s) => s.settings.showFrontMatter);
  const updateTabContent = useStore((s) => s.updateTabContent);
  const { handleNew, handleOpen } = useFileActions();
  const [splitPos, setSplitPos] = useState(50);
  const previewRef = useRef<PreviewHandle>(null);
  const syncing = useRef(false);

  const canSyncSelection = syncSelection && viewMode === "split";

  const dragging = useRef(false);
  const paneRef = useRef<HTMLDivElement>(null);

  const onDividerDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    dragging.current = true;
    const onMove = (ev: MouseEvent) => {
      if (!dragging.current || !paneRef.current) return;
      const rect = paneRef.current.getBoundingClientRect();
      const pct = ((ev.clientX - rect.left) / rect.width) * 100;
      setSplitPos(Math.max(20, Math.min(80, pct)));
    };
    const onUp = () => {
      dragging.current = false;
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  }, []);

  const onEditorSelectionRange = useCallback(
    (fromLine: number, toLine: number) => {
      if (!canSyncSelection || syncing.current) return;
      syncing.current = true;
      previewRef.current?.highlightRange(fromLine, toLine);
      window.setTimeout(() => {
        syncing.current = false;
      }, 50);
    },
    [canSyncSelection]
  );

  const onPreviewRangeSelect = useCallback(
    (fromLine: number, toLine: number) => {
      if (!canSyncSelection || syncing.current) return;
      syncing.current = true;
      scrollEditorToRange(fromLine, toLine, { focus: false });
      window.setTimeout(() => {
        syncing.current = false;
      }, 80);
    },
    [canSyncSelection]
  );

  const onDrop = useCallback(
    async (e: React.DragEvent) => {
      e.preventDefault();
      const files = Array.from(e.dataTransfer.files);
      if (!files.length || !activeTab) return;
      const file = files[0];
      if (file.type.startsWith("image/")) {
        const url = URL.createObjectURL(file);
        const snippet = `\n![${file.name}](${url})\n`;
        updateTabContent(activeTab.id, activeTab.content + snippet);
        return;
      }
      if (file.name.match(/\.(md|markdown|txt)$/i)) {
        const text = await file.text();
        updateTabContent(activeTab.id, text);
      }
    },
    [activeTab, updateTabContent]
  );

  if (!activeTab) {
    return (
      <div className={styles.empty}>
        <div className={styles.emptyInner}>
          <div className={styles.emptyLogo}>MD</div>
          <p className={styles.emptyTitle}>Start writing</p>
          <span className={styles.emptyHint}>
            Create a new file or open an existing markdown document
          </span>
          <div className={styles.emptyActions}>
            <button type="button" className={styles.emptyBtn} onClick={handleNew}>
              <Plus size={14} />
              New file
            </button>
            <button type="button" className={styles.emptyBtn} onClick={() => void handleOpen()}>
              <FolderOpen size={14} />
              Open file
            </button>
            <button
              type="button"
              className={`${styles.emptyBtn} ${styles.emptyBtnGhost}`}
              onClick={() => setViewMode("split")}
            >
              <Columns2 size={14} />
              Split view
            </button>
          </div>
          <span className={styles.emptyShortcuts}>
            Ctrl+N · Ctrl+O · Ctrl+Shift+P
          </span>
        </div>
      </div>
    );
  }

  const showEditor = viewMode === "edit" || viewMode === "split";
  const showPreview =
    viewMode === "preview" || viewMode === "split" || viewMode === "presentation";
  const isPresentation = viewMode === "presentation";

  return (
    <div className={`${styles.pane} ${isPresentation ? styles.presentationPane : ""}`}>
      {!focusMode && !isPresentation && <EditorToolbar />}
      {showFrontMatter && !isPresentation && (
        <FrontMatterPanel tab={activeTab} />
      )}
      <div
        className={styles.editorArea}
        ref={paneRef}
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
      >
        {showEditor && !isPresentation && (
          <div
            className={styles.editorWrap}
            style={viewMode === "split" ? { flex: `0 0 ${splitPos}%` } : undefined}
          >
            <MarkdownEditor
              tab={activeTab}
              onSelectionRange={onEditorSelectionRange}
            />
          </div>
        )}

        {viewMode === "split" && (
          <div className={styles.divider} onMouseDown={onDividerDown}>
            <div className={styles.dividerLine} />
          </div>
        )}

        {showPreview && (
          <div
            className={styles.previewWrap}
            style={viewMode === "split" ? { flex: `0 0 ${100 - splitPos}%` } : undefined}
          >
            <MarkdownPreview
              ref={previewRef}
              content={activeTab.content}
              onRangeSelect={onPreviewRangeSelect}
              syncSelection={canSyncSelection}
            />
          </div>
        )}
      </div>
    </div>
  );
}
