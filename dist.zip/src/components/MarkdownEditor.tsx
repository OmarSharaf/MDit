import { useEffect, useRef, useCallback, useMemo } from "react";
import CodeMirror from "@uiw/react-codemirror";
import { markdown, markdownLanguage } from "@codemirror/lang-markdown";
import { languages } from "@codemirror/language-data";
import { oneDark } from "@codemirror/theme-one-dark";
import { EditorView, lineNumbers, scrollPastEnd } from "@codemirror/view";
import { useStore, FileTab } from "../store/useStore";
import { setEditorView } from "../utils/editorRef";
import styles from "./MarkdownEditor.module.css";

interface Props {
  tab: FileTab;
  onSelectionRange?: (fromLine: number, toLine: number) => void;
}

export function MarkdownEditor({ tab, onSelectionRange }: Props) {
  const updateTabContent = useStore((s) => s.updateTabContent);
  const setEditorCursor = useStore((s) => s.setEditorCursor);
  const settings = useStore((s) => s.settings);
  const openSearch = useStore((s) => s.openSearch);
  const viewRef = useRef<EditorView | null>(null);
  const onSelectionRangeRef = useRef(onSelectionRange);
  onSelectionRangeRef.current = onSelectionRange;

  useEffect(() => {
    return () => setEditorView(null);
  }, []);

  const cursorExtension = useMemo(
    () =>
      EditorView.updateListener.of((update) => {
        if (!update.selectionSet) return;
        const main = update.state.selection.main;
        const fromLine = update.state.doc.lineAt(main.from).number;
        const toLine = update.state.doc.lineAt(main.to).number;
        setEditorCursor(
          update.state.doc.lineAt(main.head).number,
          main.head - update.state.doc.lineAt(main.head).from + 1
        );
        if (onSelectionRangeRef.current) {
          onSelectionRangeRef.current(fromLine, toLine);
        }
      }),
    [setEditorCursor]
  );

  const extensions = useMemo(
    () => [
      markdown({ base: markdownLanguage, codeLanguages: languages }),
      ...(settings.wordWrap ? [EditorView.lineWrapping] : []),
      scrollPastEnd(),
      ...(settings.showLineNumbers ? [lineNumbers()] : []),
      cursorExtension,
      EditorView.theme({
        "&": { height: "100%", fontSize: `${settings.fontSize}px` },
        ".cm-scroller": {
          fontFamily: "var(--font-mono)",
          lineHeight: String(settings.lineHeight),
          overflow: "auto",
        },
        ".cm-content": {
          caretColor: "var(--acc)",
          padding: "24px 32px",
          minHeight: "100%",
        },
        ".cm-cursor, .cm-dropCursor": { borderLeftColor: "var(--acc)" },
        "&.cm-focused .cm-selectionBackground, .cm-selectionBackground": {
          backgroundColor: "var(--acc-dim) !important",
        },
        ".cm-gutters": {
          backgroundColor: "var(--bg-1)",
          color: "var(--txt-3)",
          border: "none",
        },
      }),
    ],
    [
      settings.wordWrap,
      settings.showLineNumbers,
      settings.fontSize,
      settings.lineHeight,
      cursorExtension,
    ]
  );

  const onChange = useCallback(
    (value: string) => updateTabContent(tab.id, value),
    [tab.id, updateTabContent]
  );

  const onCreateEditor = useCallback((view: EditorView) => {
    viewRef.current = view;
    setEditorView(view);
  }, []);

  const handleKeyDown = useCallback(
    (e: React.KeyboardEvent) => {
      const mod = e.ctrlKey || e.metaKey;
      if (mod && e.key.toLowerCase() === "f") {
        e.preventDefault();
        openSearch();
      }
    },
    [openSearch]
  );

  return (
    <div
      className={`${styles.wrap} ${settings.typewriterMode ? styles.typewriter : ""}`}
      onKeyDown={handleKeyDown}
    >
      <CodeMirror
        key={`${tab.id}-${settings.fontSize}-${settings.lineHeight}-${settings.showLineNumbers}-${settings.wordWrap}-${settings.theme}`}
        value={tab.content}
        height="100%"
        theme={settings.theme === "dark" ? oneDark : "light"}
        extensions={extensions}
        onChange={onChange}
        onCreateEditor={onCreateEditor}
        basicSetup={{
          lineNumbers: false,
          foldGutter: true,
          highlightActiveLine: true,
          bracketMatching: true,
          closeBrackets: true,
          autocompletion: true,
        }}
      />
    </div>
  );
}
