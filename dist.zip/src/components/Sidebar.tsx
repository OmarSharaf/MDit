import { useState, useMemo } from "react";
import {
  FilePlus, FolderOpen, FileText, Clock, ChevronDown, ChevronRight,
  Folder, Pin, ListTree, Github
} from "lucide-react";
import { useStore, useActiveTab } from "../store/useStore";
import { useFileActions } from "../hooks/useFileActions";
import { extractHeadings } from "../utils/headings";
import { scrollEditorToLine } from "../utils/editorRef";
import { readDir } from "../utils/fileSystem";
import styles from "./Sidebar.module.css";

export function Sidebar({ onGitHubImport }: { onGitHubImport: () => void }) {
  const tabs = useStore((s) => s.tabs);
  const activeTabId = useStore((s) => s.activeTabId);
  const setActiveTab = useStore((s) => s.setActiveTab);
  const recentFiles = useStore((s) => s.recentFiles);
  const recentWorkspaces = useStore((s) => s.recentWorkspaces);
  const workspacePath = useStore((s) => s.workspacePath);
  const workspaceEntries = useStore((s) => s.workspaceEntries);
  const setWorkspaceEntries = useStore((s) => s.setWorkspaceEntries);
  const sidebarWidth = useStore((s) => s.sidebarWidth);
  const setSidebarWidth = useStore((s) => s.setSidebarWidth);
  const activeTab = useActiveTab();
  const { handleNew, handleOpen, openWorkspace, openFileFromPath } = useFileActions();

  const [openSections, setOpenSections] = useState({
    workspace: true,
    outline: true,
    openFiles: true,
    recent: true,
  });

  const outline = useMemo(
    () => (activeTab ? extractHeadings(activeTab.content) : []),
    [activeTab?.content]
  );

  const toggle = (key: keyof typeof openSections) =>
    setOpenSections((s) => ({ ...s, [key]: !s[key] }));

  const onMouseDown = (e: React.MouseEvent) => {
    e.preventDefault();
    const startX = e.clientX;
    const startW = sidebarWidth;
    const onMove = (ev: MouseEvent) => {
      setSidebarWidth(Math.max(180, Math.min(420, startW + ev.clientX - startX)));
    };
    const onUp = () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onUp);
    };
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
  };

  const loadSubdir = async (path: string) => {
    const entries = await readDir(path);
    setWorkspaceEntries(entries.filter(
      (e) => e.isDir || /\.(md|markdown|txt)$/i.test(e.name)
    ));
  };

  const sortedTabs = [...tabs].sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    return 0;
  });

  return (
    <aside className={styles.sidebar} style={{ width: sidebarWidth }}>
      <div className={styles.header}>
        <span className={styles.title}>Explorer</span>
        <div className={styles.actions}>
          <button className={styles.actionBtn} onClick={handleNew} title="New file">
            <FilePlus size={13} />
          </button>
          <button className={styles.actionBtn} onClick={handleOpen} title="Open file">
            <FolderOpen size={13} />
          </button>
          <button className={styles.actionBtn} onClick={openWorkspace} title="Open folder">
            <Folder size={13} />
          </button>
          <button className={styles.actionBtn} onClick={onGitHubImport} title="Import from GitHub">
            <Github size={13} />
          </button>
        </div>
      </div>

      <div className={styles.scroll}>
        {workspacePath && (
          <div className={styles.section}>
            <button className={styles.sectionHeader} onClick={() => toggle("workspace")}>
              {openSections.workspace ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
              <span>Workspace</span>
            </button>
            {openSections.workspace && (
              <div className={styles.fileList}>
                <div className={styles.workspacePath} title={workspacePath}>
                  {workspacePath.split(/[\\/]/).pop()}
                </div>
                {workspaceEntries.map((e) => (
                  <button
                    key={e.path}
                    className={styles.fileItem}
                    title={e.path}
                    onClick={() => {
                      if (e.isDir) void loadSubdir(e.path);
                      else void openFileFromPath(e.path, e.name);
                    }}
                  >
                    {e.isDir ? (
                      <Folder size={11} className={styles.fileIcon} />
                    ) : (
                      <FileText size={12} className={styles.fileIcon} />
                    )}
                    <span className={styles.fileName}>{e.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {outline.length > 0 && (
          <div className={styles.section}>
            <button className={styles.sectionHeader} onClick={() => toggle("outline")}>
              {openSections.outline ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
              <ListTree size={11} />
              <span>Outline</span>
            </button>
            {openSections.outline && (
              <div className={styles.fileList}>
                {outline.map((h) => (
                  <button
                    key={`${h.line}-${h.id}`}
                    className={styles.outlineItem}
                    style={{ paddingLeft: 8 + (h.level - 1) * 12 }}
                    onClick={() => scrollEditorToLine(h.line)}
                    title={h.text}
                  >
                    {h.text}
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        <div className={styles.section}>
          <button className={styles.sectionHeader} onClick={() => toggle("openFiles")}>
            {openSections.openFiles ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
            <span>Open Files</span>
            <span className={styles.badge}>{tabs.length}</span>
          </button>
          {openSections.openFiles && (
            <div className={styles.fileList}>
              {sortedTabs.map((tab) => (
                <button
                  key={tab.id}
                  className={`${styles.fileItem} ${tab.id === activeTabId ? styles.active : ""}`}
                  onClick={() => setActiveTab(tab.id)}
                  title={tab.path ?? tab.name}
                >
                  {tab.pinned && <Pin size={10} className={styles.pinIcon} />}
                  <FileText size={12} className={styles.fileIcon} />
                  <span className={styles.fileName}>{tab.name}</span>
                  {tab.isDirty && <span className={styles.dirtyDot} />}
                </button>
              ))}
            </div>
          )}
        </div>

        {recentWorkspaces.length > 0 && (
          <div className={styles.section}>
            <button className={styles.sectionHeader} onClick={() => toggle("recent")}>
              {openSections.recent ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
              <span>Recent folders</span>
            </button>
            {openSections.recent && (
              <div className={styles.fileList}>
                {recentWorkspaces.slice(0, 5).map((w, i) => (
                  <button
                    key={i}
                    className={styles.fileItem}
                    title={w.path}
                    onClick={openWorkspace}
                  >
                    <Folder size={11} className={styles.fileIcon} />
                    <span className={styles.fileName}>
                      {w.path.split(/[\\/]/).pop()}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}

        {recentFiles.length > 0 && (
          <div className={styles.section}>
            <button className={styles.sectionHeader} onClick={() => toggle("recent")}>
              {openSections.recent ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
              <span>Recent files</span>
            </button>
            {openSections.recent && (
              <div className={styles.fileList}>
                {recentFiles.slice(0, 10).map((f, i) => (
                  <button
                    key={i}
                    className={styles.fileItem}
                    title={f.path}
                    onClick={() => void openFileFromPath(f.path, f.name)}
                  >
                    <Clock size={11} className={styles.fileIcon} style={{ color: "var(--txt-3)" }} />
                    <span className={styles.fileName}>{f.name}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      <div className={styles.resizeHandle} onMouseDown={onMouseDown} />
    </aside>
  );
}
