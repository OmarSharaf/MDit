export const WELCOME_FILE_NAME = "welcome.md";

export const WELCOME_MD = `---
title: Welcome to MDit
author: Omar S. M. Abdelfatah
---

# Welcome to MDit

**MDit** is a fast Markdown editor with live preview, workspace tools, and export.

> Built by **Omar S. M. Abdelfatah** · [omarsharaf.me](https://omarsharaf.me)

## Quick start

| Action | Shortcut |
| --- | --- |
| New file | **Ctrl+N** |
| Open file | **Ctrl+O** |
| Save | **Ctrl+S** |
| Command palette | **Ctrl+Shift+P** |
| Toggle sidebar | **Ctrl+\\\\** |

1. Use **Split view** (title bar) to write and preview side by side.
2. Select text in either pane — the other pane highlights the matching content.
3. Press **Ctrl+N** or **+** on the tab bar to start your own document.

## At a glance

- **Preview** — GFM, math, Mermaid diagrams, inline SVG
- **Workspace** — folders, outline, pinned tabs, session restore
- **Export** — HTML, PDF, Markdown, copy to clipboard
- **Writing** — auto-save, focus mode, word goal, front matter

---

📖 **Full documentation:** open the **features-guide.md** tab (pinned) for interface details, shortcuts, diagrams, and tips.

Happy writing.

*MDit · Markdown, done well.*
`;

/** @deprecated Use isBuiltInDoc from builtInDocs.ts */
export function isBuiltInWelcome(name: string, path: string | null): boolean {
  return name === WELCOME_FILE_NAME && path === null;
}
