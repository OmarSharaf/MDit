import { useCallback } from "react";
import { useStore, useActiveTab } from "../store/useStore";
import {
  buildExportHtml,
  copyHtmlToClipboard,
  copyMarkdownToClipboard,
  defaultExportName,
  getPreviewBodyHtml,
  markdownToPlainText,
  printHtml,
} from "../utils/export";
import { saveExportFile } from "../utils/fileSystem";

export function useExportActions() {
  const activeTab = useActiveTab();
  const theme = useStore((s) => s.settings.theme);
  const setSaveStatus = useStore((s) => s.setSaveStatus);

  const notify = useCallback(
    (ok: boolean, success: string, fail = "Export failed") => {
      setSaveStatus(ok ? "saved" : "error", ok ? success : fail);
      setTimeout(() => setSaveStatus("idle"), 2500);
    },
    [setSaveStatus]
  );

  const exportHtml = useCallback(async () => {
    if (!activeTab) return;
    try {
      const bodyHtml = getPreviewBodyHtml();
      const html = buildExportHtml(activeTab.name, bodyHtml, theme);
      const name = defaultExportName(activeTab.name, "html");
      const path = await saveExportFile(html, name, [
        { name: "HTML", extensions: ["html", "htm"] },
      ]);
      notify(!!path, "Exported HTML");
    } catch {
      notify(false, "", "HTML export failed");
    }
  }, [activeTab, theme, notify]);

  const exportMarkdown = useCallback(async () => {
    if (!activeTab) return;
    try {
      const name = defaultExportName(activeTab.name, "md");
      const path = await saveExportFile(activeTab.content, name, [
        { name: "Markdown", extensions: ["md", "markdown"] },
      ]);
      notify(!!path, "Exported Markdown");
    } catch {
      notify(false, "", "Markdown export failed");
    }
  }, [activeTab, notify]);

  const exportPlainText = useCallback(async () => {
    if (!activeTab) return;
    try {
      const text = markdownToPlainText(activeTab.content);
      const name = defaultExportName(activeTab.name, "txt");
      const path = await saveExportFile(text, name, [
        { name: "Plain text", extensions: ["txt"] },
      ]);
      notify(!!path, "Exported plain text");
    } catch {
      notify(false, "", "Text export failed");
    }
  }, [activeTab, notify]);

  const copyHtml = useCallback(async () => {
    if (!activeTab) return;
    try {
      const bodyHtml = getPreviewBodyHtml();
      const html = buildExportHtml(activeTab.name, bodyHtml, theme);
      await copyHtmlToClipboard(html);
      notify(true, "HTML copied to clipboard");
    } catch {
      notify(false, "", "Copy failed");
    }
  }, [activeTab, theme, notify]);

  const copyMarkdown = useCallback(async () => {
    if (!activeTab) return;
    try {
      await copyMarkdownToClipboard(activeTab.content);
      notify(true, "Markdown copied to clipboard");
    } catch {
      notify(false, "", "Copy failed");
    }
  }, [activeTab, notify]);

  const exportPdf = useCallback(() => {
    if (!activeTab) return;
    try {
      const bodyHtml = getPreviewBodyHtml();
      printHtml(buildExportHtml(activeTab.name, bodyHtml, theme));
      notify(true, "Opened print dialog");
    } catch {
      notify(false, "", "Print failed");
    }
  }, [activeTab, theme, notify]);

  return {
    exportHtml,
    exportMarkdown,
    exportPlainText,
    exportPdf,
    copyHtml,
    copyMarkdown,
    hasActiveTab: !!activeTab,
  };
}
