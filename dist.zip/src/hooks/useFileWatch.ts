import { useEffect } from "react";
import { useStore, useActiveTab } from "../store/useStore";
import { readFileMeta, readTextFilePath } from "../utils/fileSystem";

export function useFileWatch() {
  const activeTab = useActiveTab();
  const reloadTabFromDisk = useStore((s) => s.reloadTabFromDisk);

  useEffect(() => {
    if (!activeTab?.path) return;

    const interval = setInterval(async () => {
      const meta = await readFileMeta(activeTab.path!);
      if (!meta || meta.isDir) return;
      if (
        activeTab.fileModifiedAt &&
        meta.modified <= activeTab.fileModifiedAt
      ) {
        return;
      }
      if (activeTab.isDirty) return;

      const content = await readTextFilePath(activeTab.path!);
      if (content !== null && content !== activeTab.content) {
        const reload = confirm(
          `"${activeTab.name}" changed on disk. Reload?`
        );
        if (reload) {
          reloadTabFromDisk(activeTab.id, content, meta.modified);
        }
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [activeTab?.id, activeTab?.path, activeTab?.isDirty, activeTab?.content, activeTab?.fileModifiedAt, reloadTabFromDisk]);
}
