import { useEffect } from "react";
import { useStore } from "../store/useStore";

export function useTheme() {
  const theme = useStore((s) => s.settings.theme);

  useEffect(() => {
    document.documentElement.setAttribute("data-theme", theme);
  }, [theme]);
}
